package appointment_mvc.controller;
import appointment_mvc.model.*;
import ch.qos.logback.core.net.SyslogOutputStream;
import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@Controller
@RequestMapping("/doctor")
public class DoctorController {
	
	static final String DOCTOR_MS_URL="http://localhost:8085/";

	@Autowired
	private RestTemplate restTemplate;
	
	
	
	@GetMapping("/home")
	public String HomeLogin()
	{
		return "doctorForm";
	}
	
	
	@PostMapping("/processlogin")
	public String loginProcess(@RequestParam("email") String email,@RequestParam("password") String password,Model model)
	{
		Doctor doctor=restTemplate.getForObject(DOCTOR_MS_URL+"doctor/"+email,Doctor.class, HttpMethod.GET);
		if(doctor.getPassword().equals(password))
		{
			List<Appointment> list = restTemplate.getForObject(DOCTOR_MS_URL+"appointment/doctor/"+doctor.getName(),List.class, HttpMethod.GET);
			System.out.println(list);
			System.out.println(doctor);
			
			model.addAttribute("list", list);
			return "welcomeDoctor";
			
		}else{
				return "doctorForm";
		}
	}
	

	@GetMapping("/register")
	public String RegisterForm()
	{
		return "doctorRegistrationForm";
	}
	
	@PostMapping("/processregiter")
	public  String registerDoctor(@ModelAttribute("Doctor") Doctor doctor){
		String postForObject = restTemplate.postForObject(DOCTOR_MS_URL+"doctor/add",doctor, String.class);
		System.out.println(postForObject);
		return "doctorForm";
	}
	

//	@PostMapping("/responeding")
//	public void responding(@ModelAttribute("appointment") Appointment appointment)
//	{
//		Long bookId = appointment.getBookId();
//		String postForObject = restTemplate.postForObject(DOCTOR_MS_URL+"appointment/respondAppointment/"+bookId,HttpMethod.GET, String.class);
//		System.out.println(postForObject);
//		
//	}
	
	@GetMapping("/treating/{bookId}")
	public String treatingProcess(@PathVariable("bookId") int bookId,Model model)
	{
		String postForObject = restTemplate.getForObject(DOCTOR_MS_URL+"appointment/treatAppointment/"+bookId, String.class);
		System.out.println(postForObject);
		Appointment appointment = restTemplate.getForObject(DOCTOR_MS_URL+"appointment/"+bookId,Appointment.class);
		List<Appointment> list = restTemplate.getForObject(DOCTOR_MS_URL+"appointment/doctor/"+appointment.getDoctorName(),List.class, HttpMethod.GET);
		System.out.println(list);
		
		model.addAttribute("list", list);
		 return "welcomeDoctor";
	}
	
	
}
