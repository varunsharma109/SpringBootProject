package appointment_mvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import appointment_mvc.model.Appointment;
import appointment_mvc.model.Doctor;
import appointment_mvc.model.Patient;

@Controller
@RequestMapping("/patient")
public class PatientController {

	
	@Autowired
	private RestTemplate restTemplate;
	static final String PATIENT_MS_URL="http://localhost:8085/";

	@GetMapping("/home")
	public String Homelogin()
	{
		
		return "patientForm";
	}
	
	@PostMapping("/processlogin")
	public String loginProcess(@RequestParam("email") String email,@RequestParam("password") String password)
	{
		Patient patient = restTemplate.getForObject(PATIENT_MS_URL+"patient/"+email,Patient.class, HttpMethod.GET);
		System.out.println(patient);
		if(patient.getPassword().equals(password))
		{
			return "welcomePatient";
			
		}else{
				return "patientForm";
		}
	}
	
	
	
	@GetMapping("/register")
	public String about()
	{
		return "patientRegistrationForm";
	}
	
	@PostMapping("/processregiter")
	public  String registerDoctor(@ModelAttribute("patient") Patient patient) {
		System.out.println(patient);
		String postForObject = restTemplate.postForObject(PATIENT_MS_URL+"patient/add",patient,String.class);
		System.out.println(postForObject);
		return "patientForm";
	}
	
	
	
	@PostMapping("viewappointment/{email}")
	public String viewAllAppointment(@RequestParam("email") String email,Model model)
	{
		List<Appointment> list = restTemplate.getForObject(PATIENT_MS_URL+"appointment/doctor/"+email,List.class, HttpMethod.GET);
		model.addAttribute("list", list); 
		return "viewpatientappointments";
	}

//	@GetMapping("/searchdoctor")
//	public String searchdoctor()
//	{
//		return "searchDoctor";
//	}

	@PostMapping("/searchdoctor")
	public String getDoctorsByCategor(@RequestParam("category") String category,Model model){
		System.out.println(" category :"+category);
	  List<Doctor> doctorList=restTemplate.getForObject(PATIENT_MS_URL+"doctor/"+category,List.class, HttpMethod.GET);
	  model.addAttribute("doctorList",doctorList);
	  return "searchDoctor";
	}
	
	@PostMapping("/payment")
	public String payment(@ModelAttribute("appointment") Appointment appointment,Model model)
	{ 
		String object = restTemplate.getForObject(PATIENT_MS_URL+"payment/"+appointment.getBookId(),String.class, HttpMethod.GET);
		System.out.println(object);
		List<Appointment> list = restTemplate.getForObject(PATIENT_MS_URL+"appointment/doctor/"+appointment.getPatientName(),List.class, HttpMethod.GET);
		model.addAttribute("list", list); 
		return "viewpatientappointments";
	}
	
	
}
