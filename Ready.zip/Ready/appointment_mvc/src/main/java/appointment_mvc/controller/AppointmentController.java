package appointment_mvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

//import appointment_mvc.model.appointment;

@Controller
@RequestMapping("/appointment")
public class AppointmentController{
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	
	@GetMapping("/home")
	public String Home()
	{
		return "appointmentForm";
	}

}
