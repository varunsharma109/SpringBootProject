package vidyanand.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VidyanandEurekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
